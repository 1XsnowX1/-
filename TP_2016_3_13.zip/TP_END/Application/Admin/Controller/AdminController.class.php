<?php
namespace Admin\Controller;
use Think\Controller;
class AdminController extends Controller{
	//检查登录
	public function __construct(){
		parent::__construct();
		if(!session('?admin_name')){
			$this->error('非法用户，请先登录！', U('Index/login'));
		}
	}
	//管理员列表展示功能
	public function showAdmin(){
		//实例化admin模型对象
		$model = M('admin');
		//判断参数admin_level,如果有使用则使用I方法接受并赋值给$admin_level,否则返回默认值1
		$admin_level = I('param.admin_level',1);
		$aid = I('param.aid',1);
		//以数组的形式组合查询条件
		$where = array('admin_level' => $admin_level);
		//通过模型类获取指定admin_level的管理员的信息
		$admin_info = $model->where($where)->select();
		//把admin_level分配到视图页面
		$this->assign('admin_level',$admin_level);
		//把管理员信息分配到指定页面
		$this->assign('admin_info',$admin_info);
		//显示视图
		$this->display();
	}

	//管理员密码修改功能
	public function update() {
        //获取admin模型类对象
        $model = M('admin');
        //组合查询条件
        $where = array(
            'aname' => I('get.aname'),
        );
        //判断是否有POST数据，如果有则说明需要进行数据更新
        if (IS_POST) {
            //使用create方法获取表单数据
            $admin_info = $model->create();
            //使用save方法进行数据更新
            if ($model->save() !== false) {
                //更新成功，则提示相关信息并跳转到当前学生所属班级的学生列表页
                $this->success('管理员信息更新成功，正在跳转，请稍候！', U("showAdmin"));
                return;
            }
            //更新失败，提示相关信息并跳转到上一页面
            $this->error('管理员信息更新失败，请重新输入！');
            return;
        }
        //根据查询条件获取管理员信息，由于是单条数据，因此使用find方法
        $admin_info = $model->where($where)->find();
        //判断该学生是否存在，如果不存在则提示错误信息并返回上一页面
        if (!isset($admin_info)) {
            $this->error('查询的管理员信息不存在，请重新选择！');
            return;
        }
        //实例化Major模型对象，使用relation方法进行关联操作
		// $major_info = D('major')->relation(true)->select();
        //将学生信息分配到视图页面
        $this->assign('admin_info', $admin_info);
        //将专业和班级信息分配到视图页面
        // $this->assign('major_info', $major_info);
        //显示视图
        $this->display();
    }
}
?>