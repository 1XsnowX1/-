<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>学生管理系统</title>
	<link href="/TP_END/Public/css/style.css" rel="stylesheet">
</head>
<body>
<div class="top">
	<div class="top-box">
		<h1 class="top-box-logo">学生管理系统</h1>
		<div class="top-box-nav">
			欢迎您！<a href="">我的信息</a> <a href="/TP_END/index.php/Admin/Admin/update">密码修改</a> <a href="/TP_END/index.php/Admin/Index/logout">安全退出</a>
		</div>
	</div>
</div>
<div class="main">
	<div class="main-left">
		<div class="main-left-nav">
			<div class="main-left-nav-head">
				<strong>院系专业</strong><div></div>
			</div>
			<a href="/TP_END/index.php/Admin/Major/showMajor">专业列表</a>
			<a href="#">添加专业</a>

			<div class="main-left-nav-head">
				<strong>学生管理</strong><div></div>
			</div>
			<div class="main-left-nav-list">
				<div><a href="/TP_END/index.php/Admin/Student/showList">学生列表</a></div>
				<div><a href="/TP_END/index.php/Admin/Student/add">添加学生</a></div>
				<div><a href="/TP_END/index.php/Admin/Student/addAll">批量添加</a></div>
			</div>
			<div class="main-left-nav-head">
				<strong>教学系统</strong><div></div>
			</div>
			<div class="main-left-nav-list">
				<div><a href="/TP_END/index.php/Admin/Subject/showSubject">科目管理</a></div>
				<div><a href="">成绩查看</a></div>
				<div><a href="">成绩录入</a></div>
				<div><a href="">成绩报表</a></div>
			</div>
			<div class="main-left-nav-head">
				<strong>教务管理</strong><div></div>
			</div>
			<div>
				<div><a href="/TP_END/index.php/Admin/Admin/showAdmin">管理员管理</a></div>
			</div>
		</div>
	</div>
	<div class="main-right">
<h2 class="main-right-nav">教学管理 &gt; 管理员管理</h2>
<div class="main-right-titbox">
	<ul><li><a href="#">管理员列表</a></li></ul>
</div>
<form method="post">请选择管理员权限等级：
	<select name="admin_level">
		<?php if(is_array($admin_info)): foreach($admin_info as $key=>$v): ?><!-- <option value="<?php echo ($v["aid"]); ?>" <?php if(($aid) == $v["aid"]): ?>selected<?php endif; ?>><?php echo ($v["admin_level"]); ?></option> -->
				<option value="<?php echo ($v["aid"]); ?>" <?php if(($aid) == $v["aid"]): ?>selected<?php endif; ?>><?php echo ($v["admin_level"]); ?></option><?php endforeach; endif; ?>
	</select>
	<input type="submit" value="确定" class="form-btn" />
</form>
<table class="table">
	<tr><th>管理员id</th><th>管理员名</th><th>操作</th></tr>
	<?php if(!empty($admin_info)): if(is_array($admin_info)): foreach($admin_info as $key=>$v): ?><tr align="center">
				<td><?php echo ($v["aid"]); ?></td>
				<td><?php echo ($v["aname"]); ?></td>
				<td><div align="center"><a href="">编辑</a>&nbsp; &nbsp;<a href=""  onclick="javascript:if(confirm('开发中')){return true;}return false;">删除</a></div></td>
			</tr><?php endforeach; endif; ?>
		<?php else: ?>
		<tr align="center"><td colspan="5">查询的结果不存在！</td></tr><?php endif; ?>
</table>
	</div>
	<div class="main-footer">
		<div>学生成绩管理系统　@copyright 2016</div>
	</div>
</div>
</body>
</html>