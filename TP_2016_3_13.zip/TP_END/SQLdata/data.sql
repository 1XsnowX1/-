/**********创建管理员表*********/
CREATE TABLE IF NOT EXISTS `stu_admin` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员id',
  `aname` varchar(20) NOT NULL COMMENT '管理员登录名',
  `apwd` char(32) NOT NULL COMMENT '管理员密码',
  `admin_level` int(2) NOT NULL DEFAULT '1' COMMENT '管理员权限',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;
/***********验证管理员登录功能*********/
insert into `stu_admin` values(null,'admin',md5('123456'),1);
insert into `stu_admin` values(null,'teacher',md5('123456'),2);
/***********创建专业表***********/
create table `stu_major`(
	`major_id` int unsigned primary key auto_increment comment '专业id',
	`major_name` varchar(20) not null comment '专业名'
)charset = utf8;
/***********插入测试数据********/
insert into `stu_major` values(1,'电子科学与技术');
insert into `stu_major` values(2,'光电信息与技术');
insert into `stu_major` values(3,'集成电路');
insert into `stu_major` values(4,'微电子');
/***********创建班级表********/
create table `stu_class`(
	`class_id` int unsigned primary key auto_increment comment '班级id',
	`class_name` varchar(8) not null comment '班级名',
	`major_id` int unsigned not null comment '专业id'
)charset = utf8;
/*********插入测试数据***********/
insert into `stu_class` values(1,'1班',1);
insert into `stu_class` values(2,'2班',1);
insert into `stu_class` values(3,'3班',1);
insert into `stu_class` values(4,'4班',1);
insert into `stu_class` values(5,'5班',1);
insert into `stu_class` values(6,'1班',2);
insert into `stu_class` values(7,'2班',2);
insert into `stu_class` values(8,'3班',2);
insert into `stu_class` values(9,'4班',2);
insert into `stu_class` values(10,'5班',2);
insert into `stu_class` values(11,'1班',3);
insert into `stu_class` values(12,'2班',3);
insert into `stu_class` values(13,'3班',3);
insert into `stu_class` values(14,'1班',4);
insert into `stu_class` values(15,'2班',4);
insert into `stu_class` values(16,'3班',4);
/**********创建学生表**************/
create table `stu_student`(
	`student_id` int unsigned primary key auto_increment,
	`student_number` varchar(12),
	`student_name` varchar(20) not null,
	`student_birthday` date not null,
	`student_gender` enum('女','男') not null default '男',
	`class_id` int unsigned not null
)charset=utf8;
ALTER TABLE `stu_student` ADD UNIQUE(`student_number`);
/*********插入测试数据***********/
insert into `stu_student` values
(1,'201513627','李宜东','1997-10-10','男',4);
/*********创建科目表************/
create table `stu_subject`(
	`subject_id` int unsigned primary key auto_increment comment '科目id',
	`subject_name` varchar(20) not null comment '科目名'
)charset = utf8;
/*********插入测试数据***********/
insert into `stu_subject` values(1,'微积分');
insert into `stu_subject` values(2,'工程制图');
insert into `stu_subject` values(3,'大学英语');
insert into `stu_subject` values(4,'信息技术导论');
/*********创建班级与科目的关系表********/
CREATE TABLE IF NOT EXISTS `stu_subject_class` (
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL
)CHARSET=utf8;
insert into `stu_class_subject` values
(4,1),
(4,2),
(4,3),
(4,4);